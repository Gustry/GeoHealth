## Projection
* EPSG:4326
* EPSG:32740

## Licence
* ODBL OpenStreetMap Contributors

## Style
* Style for roads from InaSAFE