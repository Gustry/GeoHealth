#!/bin/bash
cp -R . ~/.qgis2/python/plugins/GeoPublicHealth