10740
=====

Albuquerque, New Mexico, Census 2000 Tract Data
-----------------------------------------------

* 10740.dbf: attribute data. (k=5) 
* 10740.shp: shapefile. (n=195)
* 10740.shx: spatial index.
* 10740_queen.gal: queen contiguity weights in GAL format.
* 10740_rook.gal: rook contiguity weights in GAL format.
