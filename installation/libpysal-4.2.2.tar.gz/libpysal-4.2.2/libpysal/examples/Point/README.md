Point
=====

Point Shapefile
---------------

* Point.dbf: attribute data. (k=3)
* Point.prj: ESRI projection file.
* Point.shp: Point shapefile. (n=9)
* Point.shx: spatial index.

Used for testing
