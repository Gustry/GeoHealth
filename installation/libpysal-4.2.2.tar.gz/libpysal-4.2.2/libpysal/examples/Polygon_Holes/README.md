Polygon_Holes
=================

Example to test treatment of holes
-------------------------------------

* Polygon_Holes.dbf
* Polygon_Holes.prj
* Polygon_Holes.qpj
* Polygon_Holes.shp
* Polygon_Holes.shx
