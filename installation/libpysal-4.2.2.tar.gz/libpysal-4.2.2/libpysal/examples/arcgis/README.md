arcgis
======

arcgis testing files
--------------------

* arcgis_ohio.dbf: spatial weights in ArcGIS DBF format.
* arcgis_txt.txt: spatial weights in ArcGIS TXT format.

Files used for internal testing.
