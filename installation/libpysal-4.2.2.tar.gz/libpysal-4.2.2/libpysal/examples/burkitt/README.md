burkitt
=======

Burkitt's lymphoma in the Western Nile district of Uganda
---------------------------------------------------------

* burkitt.dbf: attribute data. (k=6)
* burkitt.shp: Point shapefile. (n=188)
* burkitt.shx: spatial index.
