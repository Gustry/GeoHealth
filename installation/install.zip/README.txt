1/3/2020

- As QGIS 3 does not support python module integration, we have run it from OSGEO command prompt. 
Please follow the follwing steps to make the plugin works.

For windows 
- Download Install.zip 
- Extract 
- Run install.bat



Or install the packages manually (provided here)

For windows 
pip install Fiona-1.8.13-cp37-cp37m-win_amd64.whl pysal-2.1.0-py3-none-any.whl libpysal-4.2.2.tar.gz


For Mac
pip install Fiona-1.8.13.post1-cp27-cp27m-macosx_10_9_x86_64 pysal-2.1.0-py3-none-any.whl libpysal-4.2.2.tar.gz


3. Lauch QGIS, it should up and running.