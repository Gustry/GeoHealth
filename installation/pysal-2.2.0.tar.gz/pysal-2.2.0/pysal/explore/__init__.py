import esda
import giddy
import inequality
import pointpats
import spaghetti
import segregation
